

<?php $__env->startSection('title', 'Quản lý đơn hàng'); ?>
<?php $__env->startSection('page-title', 'Quản lý đơn hàng'); ?>

<?php $__env->startSection('content'); ?>
<!-- Actions -->
<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="mb-0">Quản lý đơn hàng</h2>
    <a href="<?php echo e(route('admin.orders.create')); ?>" class="btn btn-primary">
        <i class="bi bi-plus-circle"></i> Tạo đơn hàng mới
    </a>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.orders.index')); ?>">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="search" class="form-label">Tìm kiếm</label>
                    <input type="text" class="form-control" id="search" name="search" 
                           value="<?php echo e(request('search')); ?>" placeholder="Tên, SĐT, mã đơn hàng...">
                </div>
                <div class="col-md-2 mb-3">
                    <label for="status" class="form-label">Trạng thái</label>
                    <select class="form-select" id="status" name="status">
                        <option value="">Tất cả</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Chờ xác nhận</option>
                        <option value="confirmed" <?php echo e(request('status') == 'confirmed' ? 'selected' : ''); ?>>Đã xác nhận</option>
                        <option value="processing" <?php echo e(request('status') == 'processing' ? 'selected' : ''); ?>>Đang xử lý</option>
                        <option value="shipped" <?php echo e(request('status') == 'shipped' ? 'selected' : ''); ?>>Đang giao</option>
                        <option value="delivered" <?php echo e(request('status') == 'delivered' ? 'selected' : ''); ?>>Đã giao</option>
                        <option value="canceled" <?php echo e(request('status') == 'canceled' ? 'selected' : ''); ?>>Đã hủy</option>
                    </select>
                </div>
                <div class="col-md-2 mb-3">
                    <label for="from" class="form-label">Từ ngày</label>
                    <input type="date" class="form-control" id="from" name="from" 
                           value="<?php echo e(request('from')); ?>">
                </div>
                <div class="col-md-2 mb-3">
                    <label for="to" class="form-label">Đến ngày</label>
                    <input type="date" class="form-control" id="to" name="to" 
                           value="<?php echo e(request('to')); ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label class="form-label">&nbsp;</label>
                    <div class="d-grid gap-2 d-md-flex">
                        <button type="submit" class="btn btn-outline-primary">Lọc</button>
                        <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline-secondary">Xóa bộ lọc</a>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Orders Table -->
<div class="card">
    <div class="card-body">
        <?php if($orders->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Mã đơn hàng</th>
                            <th>Khách hàng</th>
                            <th>Số điện thoại</th>
                            <th>Thời gian đặt</th>
                            <th>Tổng tiền</th>
                            <th>Trạng thái</th>
                            <th>Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div>
                                        <strong>#<?php echo e($order->short_id); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($order->payment_method_label); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <h6 class="mb-1"><?php echo e($order->customer_name); ?></h6>
                                        <small class="text-muted"><?php echo e(Str::limit($order->customer_address, 30)); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <span class="text-muted"><?php echo e($order->customer_phone); ?></span>
                                </td>
                                <td>
                                    <div>
                                        <div><?php echo e($order->placed_at->format('d/m/Y')); ?></div>
                                        <small class="text-muted"><?php echo e($order->placed_at->format('H:i')); ?></small>
                                    </div>
                                </td>
                                <td>
                                    <span class="fw-bold text-primary"><?php echo e(money_vnd($order->grand_total)); ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-status bg-<?php echo e(getStatusColor($order->status)); ?>">
                                        <?php echo e($order->status_label); ?>

                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('admin.orders.show', $order)); ?>" 
                                           class="btn btn-sm btn-outline-primary" 
                                           data-bs-toggle="tooltip" title="Xem chi tiết">
                                            <i class="bi bi-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.orders.print', $order)); ?>" 
                                           class="btn btn-sm btn-outline-info" 
                                           data-bs-toggle="tooltip" title="In hóa đơn" target="_blank">
                                            <i class="bi bi-printer"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-4">
                <?php echo e($orders->appends(request()->query())->links()); ?>

            </div>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="bi bi-inbox text-muted" style="font-size: 4rem;"></i>
                <h4 class="text-muted mt-3">Chưa có đơn hàng nào</h4>
                <p class="text-muted">Các đơn hàng sẽ hiển thị ở đây</p>
            </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/admin/orders/index.blade.php ENDPATH**/ ?>