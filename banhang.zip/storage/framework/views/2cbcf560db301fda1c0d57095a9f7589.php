

<?php $__env->startSection('title', 'Chi tiết đơn hàng #' . $order->short_id); ?>
<?php $__env->startSection('page-title', 'Chi tiết đơn hàng #' . $order->short_id); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <!-- Order Information -->
    <div class="col-lg-8">
        <!-- Customer Information -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Thông tin khách hàng</h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <h6>Họ tên:</h6>
                        <p class="text-muted"><?php echo e($order->customer_name); ?></p>
                        
                        <h6>Số điện thoại:</h6>
                        <p class="text-muted"><?php echo e($order->customer_phone); ?></p>
                    </div>
                    <div class="col-md-6">
                        <h6>Địa chỉ nhận hàng:</h6>
                        <p class="text-muted"><?php echo e($order->customer_address); ?></p>
                        
                        <h6>Thời gian nhận hàng:</h6>
                        <p class="text-muted"><?php echo e($order->receive_at->format('d/m/Y H:i')); ?></p>
                    </div>
                </div>
                
                <?php if($order->note): ?>
                    <hr>
                    <h6>Ghi chú:</h6>
                    <p class="text-muted"><?php echo e($order->note); ?></p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Order Items -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Sản phẩm trong đơn hàng</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Sản phẩm</th>
                                <th>SKU</th>
                                <th>Số lượng</th>
                                <th>Đơn giá</th>
                                <th>Thành tiền</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="me-3">
                                                <i class="bi bi-box text-muted" style="font-size: 2rem;"></i>
                                            </div>
                                            <div>
                                                <h6 class="mb-1"><?php echo e($item->product_name); ?></h6>
                                            </div>
                                        </div>
                                    </td>
                                    <td><code><?php echo e($item->sku); ?></code></td>
                                    <td><?php echo e($item->qty); ?></td>
                                    <td><?php echo e(money_vnd($item->unit_price)); ?></td>
                                    <td class="fw-bold"><?php echo e(money_vnd($item->line_total)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-end fw-bold">Tạm tính:</td>
                                <td class="fw-bold"><?php echo e(money_vnd($order->subtotal)); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end">Phí vận chuyển:</td>
                                <td><?php echo e(money_vnd($order->shipping_fee)); ?></td>
                            </tr>
                            <tr>
                                <td colspan="4" class="text-end">Giảm giá:</td>
                                <td class="text-danger">-<?php echo e(money_vnd($order->discount)); ?></td>
                            </tr>
                            <tr class="table-primary">
                                <td colspan="4" class="text-end fw-bold">Tổng cộng:</td>
                                <td class="fw-bold text-primary h5"><?php echo e(money_vnd($order->grand_total)); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>
            </div>
        </div>

        <!-- Order Events -->
        <?php if($order->events->count() > 0): ?>
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Lịch sử đơn hàng</h5>
            </div>
            <div class="card-body">
                <div class="timeline">
                    <?php $__currentLoopData = $order->events->sortBy('created_at'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex mb-3">
                            <div class="flex-shrink-0">
                                <i class="bi bi-circle-fill text-primary"></i>
                            </div>
                            <div class="flex-grow-1 ms-3">
                                <h6 class="mb-1"><?php echo e($event->event); ?></h6>
                                <p class="text-muted mb-1"><?php echo e($event->created_at->format('d/m/Y H:i')); ?></p>
                                <?php if($event->actor): ?>
                                    <small class="text-muted">Bởi: <?php echo e($event->actor->name); ?></small>
                                <?php endif; ?>
                                <?php if($event->data): ?>
                                    <div class="mt-2">
                                        <small class="text-muted">
                                            <?php if(isset($event->data['note'])): ?>
                                                <strong>Ghi chú:</strong> <?php echo e($event->data['note']); ?>

                                            <?php endif; ?>
                                        </small>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

    <!-- Sidebar -->
    <div class="col-lg-4">
        <!-- Order Status -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Trạng thái đơn hàng</h5>
            </div>
            <div class="card-body">
                <div class="text-center mb-3">
                    <span class="badge badge-status bg-<?php echo e(getStatusColor($order->status)); ?> fs-6">
                        <?php echo e($order->status_label); ?>

                    </span>
                </div>

                <!-- Status Update Form -->
                <form method="POST" action="<?php echo e(route('admin.orders.update-status', $order)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="mb-3">
                        <label for="status" class="form-label">Cập nhật trạng thái</label>
                        <select class="form-select" id="status" name="status" required>
                            <option value="pending" <?php echo e($order->status == 'pending' ? 'selected' : ''); ?>>Chờ xác nhận</option>
                            <option value="confirmed" <?php echo e($order->status == 'confirmed' ? 'selected' : ''); ?>>Đã xác nhận</option>
                            <option value="processing" <?php echo e($order->status == 'processing' ? 'selected' : ''); ?>>Đang xử lý</option>
                            <option value="shipped" <?php echo e($order->status == 'shipped' ? 'selected' : ''); ?>>Đang giao</option>
                            <option value="delivered" <?php echo e($order->status == 'delivered' ? 'selected' : ''); ?>>Đã giao</option>
                            <option value="canceled" <?php echo e($order->status == 'canceled' ? 'selected' : ''); ?>>Đã hủy</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="note" class="form-label">Ghi chú (không bắt buộc)</label>
                        <textarea class="form-control" id="note" name="note" rows="3" 
                                  placeholder="Ghi chú về việc thay đổi trạng thái..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="bi bi-check-circle"></i> Cập nhật trạng thái
                    </button>
                </form>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">Tóm tắt đơn hàng</h5>
            </div>
            <div class="card-body">
                <div class="d-flex justify-content-between mb-2">
                    <span>Mã đơn hàng:</span>
                    <strong>#<?php echo e($order->short_id); ?></strong>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Ngày đặt:</span>
                    <span><?php echo e($order->placed_at->format('d/m/Y H:i')); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Phương thức thanh toán:</span>
                    <span><?php echo e($order->payment_method_label); ?></span>
                </div>
                <div class="d-flex justify-content-between mb-2">
                    <span>Trạng thái thanh toán:</span>
                    <span class="badge bg-<?php echo e($order->payment_status == 'paid' ? 'success' : ($order->payment_status == 'refunded' ? 'danger' : 'warning')); ?>">
                        <?php echo e($order->payment_status == 'paid' ? 'Đã thanh toán' : ($order->payment_status == 'refunded' ? 'Đã hoàn tiền' : 'Chưa thanh toán')); ?>

                    </span>
                </div>
                
                <?php if($order->status === 'delivered' && $order->payment_status === 'unpaid'): ?>
                <!-- Payment Status Update Form -->
                <div class="mt-3 p-3 bg-light rounded">
                    <h6 class="mb-3">Cập nhật thanh toán</h6>
                    <form method="POST" action="<?php echo e(route('admin.orders.update-payment-status', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="mb-3">
                            <label for="payment_status" class="form-label">Trạng thái thanh toán</label>
                            <select class="form-select" id="payment_status" name="payment_status" required>
                                <option value="paid" <?php echo e($order->payment_status == 'paid' ? 'selected' : ''); ?>>Đã thanh toán</option>
                                <option value="unpaid" <?php echo e($order->payment_status == 'unpaid' ? 'selected' : ''); ?>>Chưa thanh toán</option>
                                <option value="refunded" <?php echo e($order->payment_status == 'refunded' ? 'selected' : ''); ?>>Đã hoàn tiền</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="payment_note" class="form-label">Ghi chú thanh toán</label>
                            <textarea class="form-control" id="payment_note" name="note" rows="2" 
                                      placeholder="Ghi chú về việc thanh toán..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-success w-100">
                            <i class="bi bi-credit-card"></i> Cập nhật thanh toán
                        </button>
                    </form>
                </div>
                <?php elseif($order->status === 'delivered' && $order->payment_status === 'paid'): ?>
                <!-- Already Paid - Show refund option -->
                <div class="mt-3 p-3 bg-success bg-opacity-10 rounded">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-check-circle-fill text-success me-2"></i>
                        <h6 class="mb-0 text-success">Đơn hàng đã được thanh toán</h6>
                    </div>
                    <form method="POST" action="<?php echo e(route('admin.orders.update-payment-status', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="mb-3">
                            <label for="payment_status" class="form-label">Thao tác</label>
                            <select class="form-select" id="payment_status" name="payment_status" required>
                                <option value="paid" selected>Giữ nguyên - Đã thanh toán</option>
                                <option value="refunded">Hoàn tiền cho khách hàng</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="payment_note" class="form-label">Ghi chú</label>
                            <textarea class="form-control" id="payment_note" name="note" rows="2" 
                                      placeholder="Ghi chú về việc hoàn tiền..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-warning w-100">
                            <i class="bi bi-arrow-clockwise"></i> Cập nhật trạng thái
                        </button>
                    </form>
                </div>
                <?php elseif(in_array($order->status, ['confirmed', 'processing', 'shipped']) && $order->payment_status === 'unpaid'): ?>
                <!-- Pre-payment for bank transfer or MoMo -->
                <div class="mt-3 p-3 bg-info bg-opacity-10 rounded">
                    <div class="d-flex align-items-center mb-3">
                        <i class="bi bi-info-circle-fill text-info me-2"></i>
                        <h6 class="mb-0 text-info">Có thể thanh toán trước</h6>
                    </div>
                    <p class="small text-muted mb-3">
                        <?php if($order->payment_method === 'bank_transfer'): ?>
                            Khách hàng có thể chuyển khoản trước khi giao hàng
                        <?php elseif($order->payment_method === 'momo'): ?>
                            Khách hàng có thể thanh toán qua MoMo trước khi giao hàng
                        <?php endif; ?>
                    </p>
                    <form method="POST" action="<?php echo e(route('admin.orders.update-payment-status', $order)); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <div class="mb-3">
                            <label for="payment_status" class="form-label">Cập nhật thanh toán</label>
                            <select class="form-select" id="payment_status" name="payment_status" required>
                                <option value="unpaid" <?php echo e($order->payment_status == 'unpaid' ? 'selected' : ''); ?>>Chưa thanh toán</option>
                                <option value="paid">Đã thanh toán trước</option>
                                <option value="refunded">Hoàn tiền</option>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="payment_note" class="form-label">Ghi chú thanh toán</label>
                            <textarea class="form-control" id="payment_note" name="note" rows="2" 
                                      placeholder="Ghi chú về việc thanh toán trước..."></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="bi bi-credit-card"></i> Cập nhật thanh toán
                        </button>
                    </form>
                </div>
                <?php endif; ?>
                <hr>
                <div class="d-flex justify-content-between fw-bold">
                    <span>Tổng tiền:</span>
                    <span class="text-primary"><?php echo e(money_vnd($order->grand_total)); ?></span>
                </div>
            </div>
        </div>

        <!-- Actions -->
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">Thao tác</h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('admin.orders.print', $order)); ?>" 
                       class="btn btn-outline-primary" target="_blank">
                        <i class="bi bi-printer"></i> In hóa đơn
                    </a>
                    <a href="<?php echo e(route('admin.orders.index')); ?>" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left"></i> Quay lại danh sách
                    </a>
                    <?php if(auth()->check() && in_array(auth()->user()->role, ['admin','staff','kitchen'])): ?>
                    <form method="POST" action="<?php echo e(route('admin.orders.destroy', $order)); ?>" onsubmit="return confirm('Xóa đơn hàng này?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-trash"></i> Xóa đơn hàng
                        </button>
                    </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Status update form
    const statusForm = document.querySelector('form[action*="update-status"]');
    if (statusForm) {
        statusForm.addEventListener('submit', function(e) {
            const status = document.getElementById('status').value;
            const currentStatus = '<?php echo e($order->status); ?>';
            
            if (status === currentStatus) {
                e.preventDefault();
                alert('Trạng thái hiện tại đã được chọn');
                return false;
            }
            
            if (!confirm('Bạn có chắc muốn cập nhật trạng thái đơn hàng?')) {
                e.preventDefault();
                return false;
            }
        });
    }

    // Payment status update form
    const paymentForm = document.querySelector('form[action*="update-payment-status"]');
    if (paymentForm) {
        paymentForm.addEventListener('submit', function(e) {
            const paymentStatus = document.getElementById('payment_status').value;
            const currentPaymentStatus = '<?php echo e($order->payment_status); ?>';
            
            if (paymentStatus === currentPaymentStatus) {
                e.preventDefault();
                alert('Trạng thái thanh toán hiện tại đã được chọn');
                return false;
            }
            
            let confirmMessage = '';
            if (paymentStatus === 'paid') {
                confirmMessage = 'Bạn có chắc khách hàng đã thanh toán?';
            } else if (paymentStatus === 'refunded') {
                confirmMessage = 'Bạn có chắc muốn hoàn tiền cho khách hàng?';
            } else if (paymentStatus === 'unpaid') {
                confirmMessage = 'Bạn có chắc muốn đặt lại trạng thái chưa thanh toán?';
            }
            
            if (confirmMessage && !confirm(confirmMessage)) {
                e.preventDefault();
                return false;
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/admin/orders/show.blade.php ENDPATH**/ ?>