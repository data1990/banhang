<?php $__env->startSection('title', 'Cài đặt hệ thống'); ?>
<?php $__env->startSection('page-title', 'Cài đặt hệ thống'); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('admin.settings.update')); ?>">
    <?php echo csrf_field(); ?>
    
    <div class="row">
        <!-- Bank Transfer Settings -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-credit-card"></i> Thông tin chuyển khoản
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="bank_code" class="form-label">Mã ngân hàng *</label>
                        <select class="form-select <?php $__errorArgs = ['bank_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                id="bank_code" name="bank_code" required>
                            <option value="">Chọn ngân hàng</option>
                            <option value="VCB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'VCB' ? 'selected' : ''); ?>>Vietcombank (VCB)</option>
                            <option value="TCB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'TCB' ? 'selected' : ''); ?>>Techcombank (TCB)</option>
                            <option value="VPB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'VPB' ? 'selected' : ''); ?>>VPBank (VPB)</option>
                            <option value="MB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'MB' ? 'selected' : ''); ?>>MB Bank (MB)</option>
                            <option value="TPB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'TPB' ? 'selected' : ''); ?>>TPBank (TPB)</option>
                            <option value="ACB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'ACB' ? 'selected' : ''); ?>>ACB</option>
                            <option value="CTG" <?php echo e(old('bank_code', $settings['bank']['code']) == 'CTG' ? 'selected' : ''); ?>>VietinBank (CTG)</option>
                            <option value="BIDV" <?php echo e(old('bank_code', $settings['bank']['code']) == 'BIDV' ? 'selected' : ''); ?>>BIDV</option>
                            <option value="VBA" <?php echo e(old('bank_code', $settings['bank']['code']) == 'VBA' ? 'selected' : ''); ?>>Agribank (VBA)</option>
                            <option value="STB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'STB' ? 'selected' : ''); ?>>Sacombank (STB)</option>
                            <option value="SHB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'SHB' ? 'selected' : ''); ?>>SHB</option>
                            <option value="VIB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'VIB' ? 'selected' : ''); ?>>VIB</option>
                            <option value="EIB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'EIB' ? 'selected' : ''); ?>>Eximbank (EIB)</option>
                            <option value="MSB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'MSB' ? 'selected' : ''); ?>>MSB</option>
                            <option value="NCB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'NCB' ? 'selected' : ''); ?>>NCB</option>
                            <option value="SEAB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'SEAB' ? 'selected' : ''); ?>>SeABank (SEAB)</option>
                            <option value="PVB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'PVB' ? 'selected' : ''); ?>>PVcomBank (PVB)</option>
                            <option value="HDB" <?php echo e(old('bank_code', $settings['bank']['code']) == 'HDB' ? 'selected' : ''); ?>>HDBank (HDB)</option>
                        </select>
                        <div class="form-text">Cần thiết để tạo QR code thanh toán</div>
                        <?php $__errorArgs = ['bank_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="bank_account_number" class="form-label">Số tài khoản *</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['bank_account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="bank_account_number" name="bank_account_number" 
                               value="<?php echo e(old('bank_account_number', $settings['bank']['account_number'])); ?>"
                               placeholder="Nhập số tài khoản ngân hàng" required>
                        <div class="form-text">Cần thiết để tạo QR code thanh toán</div>
                        <?php $__errorArgs = ['bank_account_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="bank_account_name" class="form-label">Tên chủ tài khoản</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['bank_account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="bank_account_name" name="bank_account_name" 
                               value="<?php echo e(old('bank_account_name', $settings['bank']['account_name'])); ?>"
                               placeholder="Nhập tên chủ tài khoản">
                        <?php $__errorArgs = ['bank_account_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="bank_transfer_info" class="form-label">Thông tin chuyển khoản chi tiết</label>
                        <textarea class="form-control <?php $__errorArgs = ['bank_transfer_info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="bank_transfer_info" name="bank_transfer_info" rows="6" 
                                  placeholder="Nhập thông tin ngân hàng, số tài khoản..."><?php echo e(old('bank_transfer_info', $settings['bank']['transfer_info'])); ?></textarea>
                        <div class="form-text">Hỗ trợ HTML. Ví dụ: &lt;h4&gt;Thông tin chuyển khoản&lt;/h4&gt;</div>
                        <?php $__errorArgs = ['bank_transfer_info'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="mt-3">
                            <label class="form-label fw-semibold">Xem trước hiển thị</label>
                            <div id="bank_transfer_preview" class="border rounded p-3 bg-light">
                                <?php echo old('bank_transfer_info', $settings['bank']['transfer_info']); ?>

                            </div>
                            <small class="text-muted">Bạn có thể dùng biến: <code>{ORDER_ID}</code> để chèn mã đơn.</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Store Information -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-shop"></i> Thông tin cửa hàng
                    </h5>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="store_name" class="form-label">Tên website</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['store_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_name" name="store_name" 
                               value="<?php echo e(old('store_name', $settings['store']['name'] ?? config('app.name'))); ?>" placeholder="VD: BanHang">
                        <?php $__errorArgs = ['store_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="store_logo_url" class="form-label">Logo (URL)</label>
                        <input type="url" class="form-control <?php $__errorArgs = ['store_logo_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_logo_url" name="store_logo_url" 
                               value="<?php echo e(old('store_logo_url', $settings['store']['logo_url'] ?? '')); ?>" placeholder="https://.../logo.png">
                        <?php $__errorArgs = ['store_logo_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if(!empty($settings['store']['logo_url'])): ?>
                            <div class="mt-2">
                                <img src="<?php echo e($settings['store']['logo_url']); ?>" alt="Logo preview" style="height:40px">
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="mb-3">
                        <label for="store_slogan" class="form-label">Slogan</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['store_slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_slogan" name="store_slogan" 
                               value="<?php echo e(old('store_slogan', $settings['store']['slogan'] ?? '')); ?>" placeholder="VD: Giá tốt - Giao nhanh - Hàng chính hãng">
                        <?php $__errorArgs = ['store_slogan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="mb-3">
                        <label for="store_contact_phone" class="form-label">Số điện thoại</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['store_contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_contact_phone" name="store_contact_phone" 
                               value="<?php echo e(old('store_contact_phone', $settings['store']['contact_phone'])); ?>">
                        <?php $__errorArgs = ['store_contact_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="store_address" class="form-label">Địa chỉ</label>
                        <textarea class="form-control <?php $__errorArgs = ['store_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                  id="store_address" name="store_address" rows="3"><?php echo e(old('store_address', $settings['store']['address'])); ?></textarea>
                        <?php $__errorArgs = ['store_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="store_messenger_link" class="form-label">Link Messenger</label>
                        <input type="url" class="form-control <?php $__errorArgs = ['store_messenger_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_messenger_link" name="store_messenger_link" 
                               value="<?php echo e(old('store_messenger_link', $settings['store']['messenger_link'])); ?>"
                               placeholder="https://m.me/yourpage">
                        <?php $__errorArgs = ['store_messenger_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="store_zalo_link" class="form-label">Link Zalo</label>
                        <input type="url" class="form-control <?php $__errorArgs = ['store_zalo_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="store_zalo_link" name="store_zalo_link" 
                               value="<?php echo e(old('store_zalo_link', $settings['store']['zalo_link'])); ?>"
                               placeholder="https://zalo.me/yourzalo">
                        <?php $__errorArgs = ['store_zalo_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Zalo Integration -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-chat-dots"></i> Tích hợp Zalo
                    </h5>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="zalo_enabled" name="zalo_enabled" 
                               value="1" <?php echo e(old('zalo_enabled', $settings['zalo']['enabled']) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="zalo_enabled">Bật thông báo Zalo</label>
                    </div>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="zalo_oa_id" class="form-label">Zalo OA ID</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['zalo_oa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="zalo_oa_id" name="zalo_oa_id" 
                               value="<?php echo e(old('zalo_oa_id', $settings['zalo']['oa_id'])); ?>">
                        <?php $__errorArgs = ['zalo_oa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="zalo_access_token" class="form-label">Access Token</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['zalo_access_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="zalo_access_token" name="zalo_access_token" 
                               value="<?php echo e(old('zalo_access_token', $settings['zalo']['access_token'])); ?>"
                               placeholder="Nhập token để cập nhật">
                        <?php $__errorArgs = ['zalo_access_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text">Để trống nếu không muốn thay đổi token hiện tại</div>
                    </div>

                    <div class="d-grid">
                        <button type="submit" formaction="<?php echo e(route('admin.settings.test-zalo')); ?>" 
                                class="btn btn-outline-success">
                            <i class="bi bi-check-circle"></i> Test kết nối Zalo
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Messenger Integration -->
        <div class="col-lg-6 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">
                        <i class="bi bi-messenger"></i> Tích hợp Messenger
                    </h5>
                    <div class="form-check form-switch">
                        <input class="form-check-input" type="checkbox" id="messenger_enabled" name="messenger_enabled" 
                               value="1" <?php echo e(old('messenger_enabled', $settings['messenger']['enabled']) ? 'checked' : ''); ?>>
                        <label class="form-check-label" for="messenger_enabled">Bật thông báo Messenger</label>
                    </div>
                </div>
                <div class="card-body">
                    <div class="mb-3">
                        <label for="messenger_page_id" class="form-label">Page ID</label>
                        <input type="text" class="form-control <?php $__errorArgs = ['messenger_page_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="messenger_page_id" name="messenger_page_id" 
                               value="<?php echo e(old('messenger_page_id', $settings['messenger']['page_id'])); ?>">
                        <?php $__errorArgs = ['messenger_page_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-3">
                        <label for="messenger_page_token" class="form-label">Page Token</label>
                        <input type="password" class="form-control <?php $__errorArgs = ['messenger_page_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                               id="messenger_page_token" name="messenger_page_token" 
                               value="<?php echo e(old('messenger_page_token', $settings['messenger']['page_token'])); ?>"
                               placeholder="Nhập token để cập nhật">
                        <?php $__errorArgs = ['messenger_page_token'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <div class="form-text">Để trống nếu không muốn thay đổi token hiện tại</div>
                    </div>

                    <div class="d-grid">
                        <button type="submit" formaction="<?php echo e(route('admin.settings.test-messenger')); ?>" 
                                class="btn btn-outline-primary">
                            <i class="bi bi-check-circle"></i> Test kết nối Messenger
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Save Button -->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <h6 class="mb-1">Lưu cài đặt</h6>
                            <small class="text-muted">Tất cả thay đổi sẽ được lưu khi bạn nhấn nút "Lưu cài đặt"</small>
                        </div>
                        <button type="submit" class="btn btn-primary btn-lg">
                            <i class="bi bi-save"></i> Lưu cài đặt
                        </button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Toggle integration sections based on checkboxes
    function toggleIntegrationSection(checkboxId, sectionClass) {
        const checkbox = document.getElementById(checkboxId);
        const sections = document.querySelectorAll(sectionClass);
        
        function updateVisibility() {
            sections.forEach(section => {
                if (checkbox.checked) {
                    section.style.opacity = '1';
                    section.disabled = false;
                } else {
                    section.style.opacity = '0.5';
                    section.disabled = true;
                }
            });
        }
        
        checkbox.addEventListener('change', updateVisibility);
        updateVisibility(); // Initial state
    }
    
    // Apply to both integrations
    toggleIntegrationSection('zalo_enabled', '.zalo-section');
    toggleIntegrationSection('messenger_enabled', '.messenger-section');
    
    // Test connection buttons
    document.querySelectorAll('button[formaction*="test-"]').forEach(button => {
        button.addEventListener('click', function(e) {
            const form = this.closest('form');
            const formData = new FormData(form);
            
            // Add test flag
            formData.append('test_connection', '1');
            
            fetch(this.formAction, {
                method: 'POST',
                body: formData,
                headers: {
                    'X-CSRF-TOKEN': window.Laravel.csrfToken
                }
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('Kết nối thành công!');
                } else {
                    alert('Kết nối thất bại: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Có lỗi xảy ra khi test kết nối');
            });
            
            e.preventDefault();
        });
    });

    // Live preview for bank transfer info
    const bankInfoTextarea = document.getElementById('bank_transfer_info');
    const bankInfoPreview = document.getElementById('bank_transfer_preview');
    if (bankInfoTextarea && bankInfoPreview) {
        bankInfoTextarea.addEventListener('input', function() {
            bankInfoPreview.innerHTML = this.value;
        });
    }
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>