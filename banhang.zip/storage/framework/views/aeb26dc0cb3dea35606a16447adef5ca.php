

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-people"></i> Quản lý tài khoản</h4>
    <a href="<?php echo e(route('admin.users.create')); ?>" class="btn btn-primary"><i class="bi bi-plus"></i> Tạo tài khoản</a>
    </div>

<div class="card mb-3">
    <div class="card-body">
        <form class="row g-2">
            <div class="col-md-4">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Tìm theo tên, tài khoản, email, số điện thoại">
            </div>
            <div class="col-md-3">
                <select name="role" class="form-select">
                    <option value="">-- Tất cả vai trò --</option>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r); ?>" <?php echo e(request('role')===$r?'selected':''); ?>><?php echo e(strtoupper($r)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-secondary w-100" type="submit"><i class="bi bi-search"></i> Lọc</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-striped mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Tài khoản</th>
                    <th>Email</th>
                    <th>Điện thoại</th>
                    <th>Vai trò</th>
                    <th class="text-end">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo $user->username ?: '<span class="text-muted">-</span>'; ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone ?? '-'); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($user->role==='admin'?'danger':($user->role==='kitchen'?'warning':($user->role==='shipper'?'info':($user->role==='staff'?'primary':'secondary')))); ?>">
                                <?php echo e(strtoupper($user->role)); ?>

                            </span>
                        </td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.users.edit',$user)); ?>"><i class="bi bi-pencil"></i></a>
                            <?php if(auth()->id() !== $user->id): ?>
                            <form class="d-inline" method="POST" action="<?php echo e(route('admin.users.destroy',$user)); ?>" onsubmit="return confirm('Xóa tài khoản này?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" type="submit"><i class="bi bi-trash"></i></button>
                            </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Không có tài khoản nào</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($users->hasPages()): ?>
        <div class="card-body">
            <?php echo e($users->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/admin/users/index.blade.php ENDPATH**/ ?>