

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0"><i class="bi bi-folder"></i> Danh mục sản phẩm</h4>
    <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary"><i class="bi bi-plus"></i> Thêm danh mục</a>
</div>

<div class="card mb-3">
    <div class="card-body">
        <form class="row g-2">
            <div class="col-md-4">
                <input type="text" name="q" value="<?php echo e(request('q')); ?>" class="form-control" placeholder="Tìm theo tên danh mục">
            </div>
            <div class="col-md-2">
                <button class="btn btn-secondary w-100" type="submit"><i class="bi bi-search"></i> Lọc</button>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="table-responsive">
        <table class="table table-striped mb-0">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tên</th>
                    <th>Slug</th>
                    <th>Thuộc danh mục</th>
                    <th>Trạng thái</th>
                    <th>Thứ tự</th>
                    <th class="text-end">Hành động</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($cat->id); ?></td>
                        <td><?php echo e($cat->name); ?></td>
                        <td><code><?php echo e($cat->slug); ?></code></td>
                        <td><?php echo e($cat->parent?->name ?? '-'); ?></td>
                        <td>
                            <span class="badge bg-<?php echo e($cat->is_active ? 'success' : 'secondary'); ?>"><?php echo e($cat->is_active ? 'Hiển thị' : 'Ẩn'); ?></span>
                        </td>
                        <td><?php echo e($cat->sort_order); ?></td>
                        <td class="text-end">
                            <a class="btn btn-sm btn-outline-primary" href="<?php echo e(route('admin.categories.edit', $cat)); ?>"><i class="bi bi-pencil"></i></a>
                            <form class="d-inline" method="POST" action="<?php echo e(route('admin.categories.destroy', $cat)); ?>" onsubmit="return confirm('Xóa danh mục này?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class="btn btn-sm btn-outline-danger" type="submit"><i class="bi bi-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted py-4">Không có danh mục nào</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <?php if($categories->hasPages()): ?>
        <div class="card-body">
            <?php echo e($categories->links()); ?>

        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>