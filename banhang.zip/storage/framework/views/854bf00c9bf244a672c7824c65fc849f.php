

<?php $__env->startSection('title', 'Đặt hàng thành công'); ?>

<?php $__env->startSection('content'); ?>
<div class="container py-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="text-center mb-5">
                <i class="bi bi-check-circle-fill text-success" style="font-size: 4rem;"></i>
                <h1 class="display-4 text-success mt-3">Đặt hàng thành công!</h1>
                <p class="lead">Cảm ơn bạn đã mua sắm tại <?php echo e(config('app.name', 'BanHang')); ?></p>
            </div>

            <!-- Order Information -->
            <div class="card mb-4">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0">
                        <i class="bi bi-receipt"></i> Thông tin đơn hàng
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Mã đơn hàng:</h6>
                            <p class="fw-bold text-primary">#<?php echo e($order->short_id); ?></p>
                            
                            <h6>Khách hàng:</h6>
                            <p><?php echo e($order->customer_name); ?></p>
                            
                            <h6>Số điện thoại:</h6>
                            <p><?php echo e($order->customer_phone); ?></p>
                        </div>
                        <div class="col-md-6">
                            <h6>Thời gian nhận hàng:</h6>
                            <p><?php echo e($order->receive_at->format('d/m/Y H:i')); ?></p>
                            
                            <h6>Phương thức thanh toán:</h6>
                            <p><?php echo e($order->payment_method_label); ?></p>
                            
                            <h6>Tổng tiền:</h6>
                            <p class="fw-bold text-success h5"><?php echo e(money_vnd($order->grand_total)); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order Items -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">Sản phẩm đã đặt</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Sản phẩm</th>
                                    <th>Số lượng</th>
                                    <th>Đơn giá</th>
                                    <th>Thành tiền</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <div class="d-flex align-items-center">
                                                <div class="me-3">
                                                    <i class="bi bi-box text-muted" style="font-size: 2rem;"></i>
                                                </div>
                                                <div>
                                                    <h6 class="mb-1"><?php echo e($item->product_name); ?></h6>
                                                    <small class="text-muted">SKU: <?php echo e($item->sku); ?></small>
                                                </div>
                                            </div>
                                        </td>
                                        <td><?php echo e($item->qty); ?></td>
                                        <td><?php echo e(money_vnd($item->unit_price)); ?></td>
                                        <td class="fw-bold"><?php echo e(money_vnd($item->line_total)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3" class="text-end fw-bold">Tổng cộng:</td>
                                    <td class="fw-bold text-success"><?php echo e(money_vnd($order->grand_total)); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Payment Instructions -->
            <?php if(in_array($order->payment_method, ['qr_code', 'bank_transfer']) && $qrCode): ?>
                <div class="card mb-4">
                    <div class="card-header bg-warning">
                        <h5 class="mb-0">
                            <i class="bi bi-qr-code"></i> Hướng dẫn thanh toán
                            <?php if($order->payment_method === 'qr_code'): ?>
                                - Quét mã QR
                            <?php else: ?>
                                - Chuyển khoản
                            <?php endif; ?>
                        </h5>
                    </div>
                    <div class="card-body">
                        <!-- QR Code Payment -->
                        <div class="row">
                            <div class="<?php echo e($order->payment_method === 'qr_code' ? 'col-md-12' : 'col-md-6'); ?> text-center mb-3 mb-md-0">
                                <h6 class="mb-3">Quét mã QR để thanh toán</h6>
                                <img src="<?php echo e($qrCode); ?>" alt="QR Code" class="img-fluid border rounded" style="max-width: 300px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);">
                                <p class="text-muted mt-2 small">Quét bằng app ngân hàng để thanh toán nhanh</p>
                            </div>
                            <?php if($order->payment_method === 'bank_transfer'): ?>
                                <div class="col-md-6">
                                    <div class="alert alert-info">
                                        <h6>Hoặc chuyển khoản thủ công:</h6>
                                        <div class="mt-3">
                                            <?php echo \App\Models\Setting::get('bank.transfer_info', ''); ?>

                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                        <?php if($order->payment_method === 'bank_transfer'): ?>
                            <hr>
                        <?php endif; ?>
                        
                        <div class="bg-light p-3 rounded">
                            <strong>Nội dung chuyển khoản:</strong> 
                            <code>ORDER-<?php echo e($order->short_id); ?></code>
                        </div>
                        
                        <p class="text-muted mt-3">
                            <i class="bi bi-info-circle"></i>
                            Sau khi chuyển khoản, đơn hàng sẽ được xác nhận trong vòng 1-2 giờ làm việc.
                        </p>
                    </div>
                </div>
            <?php endif; ?>

            <!-- Contact Information -->
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="mb-0">
                        <i class="bi bi-headset"></i> Hỗ trợ khách hàng
                    </h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <h6>Thông tin liên hệ:</h6>
                            <p>
                                <i class="bi bi-telephone"></i> 
                                <?php echo e(\App\Models\Setting::get('store.contact_phone', '0123456789')); ?>

                            </p>
                            <p>
                                <i class="bi bi-geo-alt"></i> 
                                <?php echo e(\App\Models\Setting::get('store.address', '123 Đường ABC, Quận 1, TP.HCM')); ?>

                            </p>
                        </div>
                        <div class="col-md-6">
                            <h6>Liên hệ trực tuyến:</h6>
                            <div class="d-flex gap-2">
                                <?php if($messengerLink): ?>
                                    <a href="<?php echo e($messengerLink); ?>" class="btn btn-primary btn-sm" target="_blank">
                                        <i class="bi bi-messenger"></i> Messenger
                                    </a>
                                <?php endif; ?>
                                <?php if($zaloLink): ?>
                                    <a href="<?php echo e($zaloLink); ?>" class="btn btn-success btn-sm" target="_blank">
                                        <i class="bi bi-chat-dots"></i> Zalo
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Action Buttons -->
            <div class="text-center">
                <div class="d-grid gap-2 d-md-flex justify-content-md-center">
                    <a href="<?php echo e(route('account.orders')); ?>" class="btn btn-primary btn-lg">
                        <i class="bi bi-list-ul"></i> Xem đơn hàng của tôi
                    </a>
                    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-outline-primary btn-lg">
                        <i class="bi bi-shop"></i> Tiếp tục mua sắm
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-scroll to top
    window.scrollTo(0, 0);
    
    // Show success message if redirected from checkout
    <?php if(session('success')): ?>
        const toast = document.createElement('div');
        toast.className = 'toast align-items-center text-white bg-success border-0 position-fixed top-0 end-0 m-3';
        toast.style.zIndex = '9999';
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body"><?php echo e(session('success')); ?></div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        document.body.appendChild(toast);
        new bootstrap.Toast(toast).show();
    <?php endif; ?>
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\banhang\resources\views/front/checkout/success.blade.php ENDPATH**/ ?>