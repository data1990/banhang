<?php

use App\Http\Controllers\Admin\CustomersController as AdminCustomersController;
use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\OrdersController as AdminOrdersController;
use App\Http\Controllers\Admin\CategoriesController as AdminCategoriesController;
use App\Http\Controllers\Admin\ProductsController as AdminProductsController;
use App\Http\Controllers\Admin\UsersController as AdminUsersController;
use App\Http\Controllers\Admin\SettingsController as AdminSettingsController;
use App\Http\Controllers\Front\CartController;
use App\Http\Controllers\Front\CheckoutController;
use App\Http\Controllers\Front\HomeController;
use App\Http\Controllers\Front\ProductController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

// Front routes
Route::get('/', [HomeController::class, 'index'])->name('home');

Route::get('/products', [ProductController::class, 'index'])->name('products.index');
Route::get('/products/{slug}', [ProductController::class, 'show'])->name('products.show');

Route::get('/cart', [CartController::class, 'index'])->name('cart.index');
Route::get('/cart/offcanvas', [CartController::class, 'offcanvas'])->name('cart.offcanvas');
Route::post('/cart/items', [CartController::class, 'addItem'])->name('cart.add');
Route::patch('/cart/items', [CartController::class, 'updateItem'])->name('cart.update');
Route::delete('/cart/items', [CartController::class, 'removeItem'])->name('cart.remove');
Route::get('/api/cart/count', [CartController::class, 'getCount'])->name('cart.count');

Route::get('/checkout', [CheckoutController::class, 'show'])->name('checkout.show');
Route::post('/checkout', [CheckoutController::class, 'placeOrder'])->name('checkout.place');
Route::get('/checkout/success/{order}', [CheckoutController::class, 'success'])->name('checkout.success');

// Dashboard redirect based on role
Route::middleware('auth')->get('/dashboard', function () {
    /** @var \App\Models\User $user */
    $user = auth()->user();
    
    if (in_array($user->role, ['admin','staff','kitchen','shipper'])) {
        return redirect()->route('admin.dashboard');
    }
    
    return redirect()->route('account.dashboard');
})->name('dashboard');

// Account routes
Route::middleware('auth')->group(function () {
    Route::get('/account', function () {
        return view('account.dashboard');
    })->name('account.dashboard');
    
    Route::get('/account/profile', function () {
        return view('account.profile');
    })->name('account.profile');
    
    Route::get('/account/orders', function () {
        return view('account.orders');
    })->name('account.orders');
    
    Route::get('/account/orders/{order}', function ($order) {
        return view('account.order-detail', compact('order'));
    })->name('account.order-detail');
    
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

// Admin routes
Route::prefix('admin')->middleware(['auth', 'role:admin,staff,kitchen,shipper'])->group(function () {
    Route::get('/', [AdminDashboardController::class, 'index'])->name('admin.dashboard');
    
    Route::resource('products', AdminProductsController::class)->names([
        'index' => 'admin.products.index',
        'create' => 'admin.products.create',
        'store' => 'admin.products.store',
        'show' => 'admin.products.show',
        'edit' => 'admin.products.edit',
        'update' => 'admin.products.update',
        'destroy' => 'admin.products.destroy'
    ]);
    Route::patch('products/{product}/toggle-active', [AdminProductsController::class, 'toggleActive'])->name('admin.products.toggle-active');
    Route::delete('products/images/{image}', [AdminProductsController::class, 'deleteImage'])->name('admin.products.images.delete');
    Route::patch('products/images/{image}/primary', [AdminProductsController::class, 'setPrimaryImage'])->name('admin.products.images.primary');
    
    // Categories (admin, staff)
    Route::middleware('role:admin,staff')->group(function () {
        Route::resource('categories', AdminCategoriesController::class)->names([
            'index' => 'admin.categories.index',
            'create' => 'admin.categories.create',
            'store' => 'admin.categories.store',
            'edit' => 'admin.categories.edit',
            'update' => 'admin.categories.update',
            'destroy' => 'admin.categories.destroy',
            'show' => 'admin.categories.show',
        ])->except(['show']);
    });
    
    // Orders - view routes (including shipper)
    Route::get('orders', [AdminOrdersController::class, 'index'])->name('admin.orders.index');
    Route::get('orders/{order}', [AdminOrdersController::class, 'show'])->name('admin.orders.show');
    Route::get('orders/{order}/print', [AdminOrdersController::class, 'print'])->name('admin.orders.print');
    Route::get('orders/{order}/quick-view', [AdminOrdersController::class, 'quickView'])->name('admin.orders.quick-view');

    // Orders - modify routes (exclude shipper)
    Route::middleware('role:admin,staff,kitchen')->group(function () {
        Route::get('orders/create', [AdminOrdersController::class, 'create'])->name('admin.orders.create');
        Route::post('orders', [AdminOrdersController::class, 'store'])->name('admin.orders.store');
        Route::patch('orders/{order}/status', [AdminOrdersController::class, 'updateStatus'])->name('admin.orders.update-status');
        Route::patch('orders/{order}/payment-status', [AdminOrdersController::class, 'updatePaymentStatus'])->name('admin.orders.update-payment-status');
        Route::delete('orders/{order}', [AdminOrdersController::class, 'destroy'])->name('admin.orders.destroy');
    });
    
    Route::get('customers', [AdminCustomersController::class, 'index'])->name('admin.customers.index');
    Route::get('customers/detail', [AdminCustomersController::class, 'show'])->name('admin.customers.show');
    Route::middleware('role:admin')->group(function () {
        Route::delete('customers', [AdminCustomersController::class, 'destroy'])->name('admin.customers.destroy');
    });
    
    // Users - admin only
    Route::middleware('role:admin')->group(function () {
        Route::resource('users', AdminUsersController::class)->names([
            'index' => 'admin.users.index',
            'create' => 'admin.users.create',
            'store' => 'admin.users.store',
            'edit' => 'admin.users.edit',
            'update' => 'admin.users.update',
            'destroy' => 'admin.users.destroy',
            'show' => 'admin.users.show',
        ])->except(['show']);
    });
    
    Route::get('settings', [AdminSettingsController::class, 'index'])->name('admin.settings.index');
    Route::post('settings', [AdminSettingsController::class, 'update'])->name('admin.settings.update');
    Route::post('settings/test-zalo', [AdminSettingsController::class, 'testZalo'])->name('admin.settings.test-zalo');
    Route::post('settings/test-messenger', [AdminSettingsController::class, 'testMessenger'])->name('admin.settings.test-messenger');
});

require __DIR__.'/auth.php';
